Thank you for using Oi! Remember, your free licence is limited to a maximum of 3 desktop users and 10.000 unique web visitors per month. If you need to upgrade your licence get in touch (hi@kostasbartsokas.com) to get a custom quote.

For an example of how to use the webfonts on your website checkout the live promo site (www.kostasbartsokas.com/oi-you-mate) or grab the full source code from github (https://github.com/ap-o/oi-you-mate).
